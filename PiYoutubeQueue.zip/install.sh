#!/bin/bash
echo "Installing pintea-volumio-yt"

echo "plugininstallend"